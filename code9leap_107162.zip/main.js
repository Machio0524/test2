enchant(); 
window.focus();
window.onload = function() {
    var game = new Game(320, 320);
    game.fps = 24;    
    game.preload(
        "tatemono_station.png","026.png","character09.gif",'map2.png',
        "clear.png","line_cloud06.gif","school_koumon.png");
    game.onload = function() {
//背景-------------------------------------------------------------------------
    //背景色
        game.rootScene.backgroundColor="deepskyblue";
    
    //雲
        Cloud = new Group();
        for(i=0;i<30;i++){
            cloud = new Sprite(42,28); 
            cloud.image = game.assets['line_cloud06.gif'];
            cloud.x = Math.random()*3000-320;
            cloud.y = Math.random()*50;
            cloud.frame = 1;
            Cloud.addChild(cloud);
            }
        Cloud.on("enterframe",function(){
            this.x-=0.2;
            }) ;
        game.rootScene.addChild(Cloud);
    
    //床
        Floor = new Group();
        Floor.x = -320;
        for(i=0;i<200;i++){
            floor = new Sprite(17,16);
            floor.image = game.assets["map2.png"];
            floor.x = i * 16;
            floor.y = 304;
            Floor.addChild(floor);
            }
        game.rootScene.addChild(Floor);

    //スタート地点
        start = new Sprite(743, 616); 
        start.x = -500;
        start.y = -80; 
        start.scaleX = 0.4; 
        start.scaleY = 0.4; 
        start.image = game.assets['tatemono_station.png']; 
    
    //ゴール
        goal = new Sprite(800,610); // キャラの大きさは32x32
        goal.x = 2000; //クマのX座標
        goal.y = -67; //クマのY座標
        goal.scaleX = 0.5; //X座標への拡大率
        goal.scaleY = 0.5; //Y座標への拡大率
        goal.frame =2;
        goal.image = game.assets['school_koumon.png']; // chara1.gifの中にある
    
    //goal座標
        Goal = new Sprite(32,32);
        Goal.x = goal.x+360;
        Goal.y = goal.y;
        //Goal.backgroundColor = "red";
        //Goal.oppacity = 0.5;
    
//敵---------------------------------------------------------------------------
    //敵1intro
        enemys = new  Group()
            enemy1 = new Sprite(280, 300);
            enemy1.image=game.assets["026.png"]
            enemy1.frame =0;
            enemy1.x=120
            enemy1.y=130;
            enemy1.scaleX= 0.3;
            enemy1.scaleY= 0.25;
            enemy1.on("enterframe",function(){
                this.x-=1
            })
            enemys.addChild(enemy1);
    //敵1introあたり判定    
            enemy_atari1 = new Sprite(40,47);
            enemy_atari1.x=enemy1.x+112;
            enemy_atari1.y=enemy1.y+127;
            //enemy_atari1.opacity = 0.5;
            //enemy_atari1.backgroundColor = "red"
            enemy_atari1.on("enterframe",function(){
                this.x-=1
                if(this.intersect(player_atari))
                Player.vx=0
            });     
            enemys.addChild(enemy_atari1);
            
            
    //敵1    
        enemys1 = new  Group();
        for(i=1;i<5;i++){
            randam = Math.random();
            enemy1 = new Sprite(280, 300);
            enemy1.image=game.assets["026.png"]
            enemy1.frame =0;
            enemy1.x=1000+randam*500*i
            enemy1.y=130;
            enemy1.scaleX= 0.3;
            enemy1.scaleY= 0.25;
            enemy1.on("enterframe",function(){
                this.x-=1
            })
            enemys1.addChild(enemy1);
    //敵1あたり判定    
            enemy_atari1 = new Sprite(40,47);
            enemy_atari1.x=enemy1.x+112;
            enemy_atari1.y=enemy1.y+127;
            //enemy_atari1.opacity = 0.5;
            //enemy_atari1.backgroundColor = "red"
            enemy_atari1.on("enterframe",function(){
                this.x-=1
                if(this.intersect(player_atari))
                Player.vx=0
            });     
            enemys1.addChild(enemy_atari1);
            }

    //敵2intro    
        enemy2 = new Sprite(280, 300);
            enemy2.image=game.assets["026.png"]
            enemy2.frame =1;
            enemy2.x=520
            enemy2.y=135
            enemy2.scaleX= 0.3;
            enemy2.scaleY= 0.25;
            enemy2.on("enterframe",function(){
                this.x-=2
                })
            enemys.addChild(enemy2);
            
    //敵2introあたり判定    
            enemy_atari2 = new Sprite(50,41);
            enemy_atari2.x=enemy2.x+115;
            enemy_atari2.y=enemy2.y+128
            enemy_atari2.on("enterframe",function(){
                this.x-=2
                if(this.intersect(player_atari))
                Player.vx=0
                })
            //enemy_atari2.opacity = 0.5;
            //enemy_atari2.backgroundColor = "red";     
            enemys.addChild(enemy_atari2);
                
    //敵2
        enemys2 = new  Group();
        for(i=1;i<4;i++){
            randam = Math.random();
            enemy2 = new Sprite(280, 300);
            enemy2.image=game.assets["026.png"]
            enemy2.frame =1;
            enemy2.x=1500+randam*700*i
            enemy2.y=135
            enemy2.scaleX= 0.3;
            enemy2.scaleY= 0.25;
            enemy2.on("enterframe",function(){
                this.x-=2
                })
            enemys2.addChild(enemy2);
            
    //敵2あたり判定    
            enemy_atari2 = new Sprite(50,41);
            enemy_atari2.x=enemy2.x+115;
            enemy_atari2.y=enemy2.y+128
            enemy_atari2.on("enterframe",function(){
                this.x-=2
                if(this.intersect(player_atari))
                Player.vx=0
                })
            //enemy_atari2.opacity = 0.5;
            //enemy_atari2.backgroundColor = "red";     
            enemys2.addChild(enemy_atari2);
            }
        
    //敵3intro
        enemys3 = new  Group();
            enemy3 = new Sprite(280, 300);
            enemy3.image=game.assets["026.png"]
            enemy3.frame =2;
            enemy3.x=1020
            enemy3.y=128;
            enemy3.scaleX= 0.3;
            enemy3.scaleY= 0.25;
            enemy3.on("enterframe",function(){
                this.x-=4
            })
            enemys.addChild(enemy3);
    //敵3introあたり判定    
            enemy_atari3 = new Sprite(60,47);
            enemy_atari3.x=enemy3.x+106;
            enemy_atari3.y=enemy3.y+130;
            //enemy_atari3.opacity = 0.5;
            //enemy_atari3.backgroundColor = "red";  
            enemy_atari3.on("enterframe",function(){
                this.x-=4
                if(this.intersect(player_atari))
                Player.vx=0
            })
            enemys.addChild(enemy_atari3);
        
        
    //敵3
        enemys3 = new  Group();
        for(i=1;i<3;i++){
            randam = Math.random();
            enemy3 = new Sprite(280, 300);
            enemy3.image=game.assets["026.png"]
            enemy3.frame =2;
            enemy3.x=1500+randam*700*i
            enemy3.y=128;
            enemy3.scaleX= 0.3;
            enemy3.scaleY= 0.25;
            enemy3.on("enterframe",function(){
                this.x-=4
            })
            enemys3.addChild(enemy3);
    //敵3あたり判定    
            enemy_atari3 = new Sprite(60,47);
            enemy_atari3.x=enemy3.x+106;
            enemy_atari3.y=enemy3.y+130;
            //enemy_atari3.opacity = 0.5;
            //enemy_atari3.backgroundColor = "red";  
            enemy_atari3.on("enterframe",function(){
                this.x-=4
                if(this.intersect(player_atari))
                Player.vx=0
            })
            enemys3.addChild(enemy_atari3);
        }
        
    //敵4intro
            enemy4 = new Sprite(280, 300);
            enemy4.image=game.assets["026.png"]
            enemy4.frame =3;
            enemy4.x=2200
            enemy4.y=132
            enemy4.scaleX= 0.3;
            enemy4.scaleY= 0.25;
            enemy4.on("enterframe",function(){
                this.x-=10
            })
            enemys.addChild(enemy4);
            
    //敵4introあたり判定    
            enemy_atari4 = new Sprite(58,32);
            enemy_atari4.x=enemy4.x+112;
            enemy_atari4.y=enemy4.y+140;
            //enemy_atari4.opacity = 0.5;
            //enemy_atari4.backgroundColor = "red";   
            enemy_atari4.on("enterframe",function(){
                this.x-=10
                if(this.intersect(player_atari))
                Player.vx=0
            })
            enemys.addChild(enemy_atari4);
           
        
    //敵4
        enemys4 = new  Group();
        for(i=1;i<11;i++){
            randam = Math.random();
            enemy4 = new Sprite(280, 300);
            enemy4.image=game.assets["026.png"]
            enemy4.frame =3;
            enemy4.x=-400+randam*-300*i
            enemy4.y=132
            enemy4.scaleX= -0.3;
            enemy4.scaleY= 0.25;
            enemy4.on("enterframe",function(){
                if(Player.x>=1500)
                this.x+=20
            })
            enemys4.addChild(enemy4);
            
    //敵4あたり判定    
            enemy_atari4 = new Sprite(58,32);
            enemy_atari4.x=enemy4.x+112;
            enemy_atari4.y=enemy4.y+140;
            //enemy_atari4.opacity = 0.5;
            //enemy_atari4.backgroundColor = "red";   
            enemy_atari4.on("enterframe",function(){
                if(Player.x>=1500)
                this.x+=20
                if(this.intersect(player_atari))
                Player.vx=0
            })
            enemys4.addChild(enemy_atari4);
        }
        
    //グループ化        
        Enemy = new Group();
        Enemy.addChild(enemys)
        Enemy.addChild(enemys1);
        Enemy.addChild(enemys2);
        Enemy.addChild(enemys3);
        Enemy.addChild(enemys4);
//player----------------------------------------------------------------------    
        player = new Sprite(32,30);
        player.image = game.assets["character09.gif"];
        player.x=0;
        player.scaleX=1;
        player.y=20;
    
    //player_当たり判定
        player_atari = new Sprite(17,30);
        //player_atari.backgroundColor="red"
        //player_atari.opacity=0.5
        player_atari.x=8;
        player_atari.y=22;
    
    //player_グループ
        Player=new Group();
        Player.addChild(player_atari);
        Player.addChild(player);
        Player.x=0;
        Player.y=255;
        Player.vx=0;
        Player.vy=0;
            
    //player_ジャンプしていない        
        player.jumping = false;
    
    
                
        
        
    
//プレイヤーアニメーション----------------------------------------------------  
    Player.addEventListener("enterframe",function(){
    //プレイヤー操作の一時保存
        var ax = 0;

    //キー入力        
        if (game.input.right)
            ax += 0.5;    
        else if (game.input.left) 
            ax -= 0.5;
    
    //方向転換    
        if (ax > 0) 
            player.scaleX = 1;   
            
        if (ax < 0) 
            player.scaleX = -1;
    
    //左移動+減速        
        if (this.vx > 0.3)
            ax -= 0.3;
        else if (this.vx > 0)
            ax -= this.vx;
    
    //右移動+減速    
        if (this.vx < -0.3)
            ax += 0.3;
        else if (this.vx < 0)
            ax -= this.vx;
    
    //移動距離変数
        this.vx += ax;
    
    //最高速度
        this.vx = Math.min(Math.max(this.vx, -5), 5);
    
    //ジャンプ    
        if(game.input.up && (!this.jumping)) {
            this.vy = -9;
            this.jumping = true;
            }
    
    //重力
        this.vy += 0.5;
    
    //ここから左にいけません
        if(this.x<=0)
            this.x=0;
    //移動    
        this.x += this.vx;
        this.y += this.vy;
    
    //着地
        if(this.y >= 255) {
            this.y = 255;
            this.jumping = false;
            }
            
    //ゴールした時    
        if(this.x>=Goal.x){
            Time_score =  minute * 10 + second *1;
            Total_time.text=
                "残り時間:"+minute+"分"+second+"秒"+ "→ "+minute+"分×10+"+
                second+"秒×1"+"="+Time_score+"点";
//            Total_score.text=
//                "Score:"+point;
    //シーン変更
            game.pushScene(Gameclear);
            }      
        })
        
//ステージ--------------------------------------------------------------------    
        stage = new Group();
        stage.addChild(Goal);
        stage.addChild(Cloud);
        stage.addChild(goal);
        stage.addChild(Enemy);
        stage.addChild(Player);
        stage.addChild(start); 
        stage.addChild(Floor);
        
    //ステージアニメーション
        stage.addEventListener("enterframe", function() {
        //右移動    
            if(player.scaleX==1 && (stage.x>45-Player.x))
                stage.x =45-Player.x;
        
        //左移動    
            if(player.scaleX==-1)
                stage.x =250-Player.x;
            });    
        
        game.rootScene.addChild(stage);
   
   
   
//時間------------------------------------------------------------------------
        Time =  new Label("1限まであと 10分");
    //座標
        Time.x=5;
        Time.y=5;
    
    //制限時間    
        minute = 9;
        second = 59;    
        game.rootScene.addChild(Time);
        Time.addEventListener("enterframe",function(){ 
            second --;
            if(second==-1){
                minute-=1;
                second=59;
                }
    
    //タイムアップ
            if(minute==-1){
                game.end();    
                alert("間に合わなかった・・・。次からは時間にゆとりを持って登校しよう・・");
                }
    //時間表示更新
            this.text="1限まであと"+minute+"分"+second+"秒"; 
            });



//点数------------------------------------------------------------------------         
    //初期点数
//        point=0;
        
    //scoreラベル
  //      Score = new Label("Score:0");
    //    Score.x=5;
      //  Score.y=20;
    //    Score.addEventListener("enterframe",function(){
     //       this.text="Score:"+point;
      //      });
//        game.rootScene.addChild(Score);



//クリア画面------------------------------------------------------------------

    //クリアスプライト
        clear = new Sprite(270,48);
        clear.image = game.assets["clear.png"];
        clear.x = 30;
        clear.y = 60;

    //合計点
        Total= new Label("結果発表");
        Total.x=140;
        Total.y=140;
        
        Total_time = new Label();
        Total_time.x=30;
        Total_time.y=165;
        
//        Total_score= new Label();
//        Total_score.x=30;
//        Total_score.y=250;

    //クリア画面に表示
        Gameclear = new Scene();
        Gameclear.addChild(clear);
        Gameclear.addChild(Total);
        Gameclear.addChild(Total_time);
//        Gameclear.addChild(Total_score);
    
    };
    game.start();
};
        //message = new Label(
            //"ルール説明")
        //message.x=160
        //message.y=140
        //game.rootScene.addChild(message)    
        //message.addEventListener("touchstart",function(){
        //    game.pushScene(play)    
        //})
        
        //play = new Scene()
        //play.backgroundColor="white"     
        
        
